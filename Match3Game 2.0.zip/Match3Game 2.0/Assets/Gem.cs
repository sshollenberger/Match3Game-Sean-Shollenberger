﻿using UnityEngine;
using System.Collections;

public class Gem : MonoBehaviour {
	public enum Gemtype{green, blue, yellow, red, purple};
	public Gemtype gem;

	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () {
	}
}
