﻿using UnityEngine;
using System.Collections;

public class GenerateBoard : MonoBehaviour {
	public GameObject[] gemAsset;
	int randomNum;
	// Use this for initialization
	GameObject[] gemRow = new GameObject[6];
	Vector3[,] gemVector3 = new Vector3[6,6];
	Vector3[] gemRowVector3 = new Vector3[6];
	GameObject[,] gems = new GameObject[6,6];
	bool[,] match = new bool[6,6];
	GameObject gemCopy;
	bool canDoSomething = true;
	bool iCanHasMatch = false;
	public GUIText scoreTxt;
	public int score = 0;
	Ray ray;        //this is for mouseclick function
	RaycastHit hit; //this is for mouseclick function
	int[] gemSecondTouch = new int[2]{-666, -666}, gemFirstTouch = new int[2]{-666, -666}; //this is for mouseclick function
	void Start () {
		scoreTxt.text = ("Score: "+ score);
		RandomNum ();
		for (int y = 0; y < 6; y++) {
			for (int x = 0; x < 6; x++) {
				randomNum = RandomNum();
				gems[x,y] = Instantiate(gemAsset[randomNum], new Vector3(x * 1.1f, y * 1.1f, 0), Quaternion.identity) as GameObject;
				gemVector3[x,y] = gems[x,y].transform.position;//copies each position of the gems
			}
		}
		InvokeRepeating ("Check",1f, 2f); //this loops the CheckForMatches function every N seconds
	}//end Start()
	int RandomNum(){
		int random = Random.Range (0, 5);
		return random;
	}
	void DestroyGems(GameObject[,] gems, bool[,] match)
	{
		//int numberCount = 0;
		//int numberCount2 = 0;
		for (int g = 0; g<6; g++) {//loop through every gem
		for (int i = 0; i<6; i++) {
			if (match [i,g] == true) {
				Destroy (gems [i,g]); //destroy match gem gameObject **warning!! does not remove from gems array!
				RemoveGem (gems, i,g);// removes this gem from the array
				match[i,g] = false; //resets match array
			}
		}
		}
		// Reorders the array to simulate gems falling from gravity.
		for (int loopX = 0; loopX < 6; loopX++) {
		for (int loopY = 0; loopY < 6; loopY++) {
				gemRow[loopY] = gems[loopX, loopY]; //copy gems into gemRow
				if(loopY == 5){
					ConsolidateRow(gemRow);
					for (int loopZ = 0; loopZ < 6; loopZ++) {//copy gemRow back to gems
						gems[loopX,loopZ] = gemRow[loopZ];
					}
				}
		}
		}
		/*
		for (int j=0; j<6; j++) {
			for (int i = j; i<36; i+= 6) {//these for loops goes through each vertical row. example: (0 6 12 18, 1 7 13 19, 2 8 14 20...)
				//print("gem " + i + " copied to gemRow " + numberCount); 
				gemRow[numberCount] = gems[i]; //copies each gem from the vertical row. 1-6  Puts it into an array
				gemRowVector3[numberCount] = gemVector3[i]; //copies each gem position from the vertical row.  Puts it into an array
				if(numberCount<=4){ // makes numberCount 0 1 2 3 4 5....
				numberCount++;
				}else{ //when counter reaches 5, reset to zero and consolidate the row
				numberCount = 0;
				ConsolidateRow (gemRow, gemRowVector3); // consolidating the row
				for (int f = j; f<36; f+= 6){
				gems[f] = gemRow[numberCount2]; //add the row back to gems array
				//print("gemRow " + numberCount2 + " copied to gem " + f); 
				if(numberCount2<=4){ // makes numberCount 0 1 2 3 4 5....
				numberCount2++;
				}else{ //when counter reaches 5, reset to zero and consolidate the row
				numberCount2 = 0;
				}
				}
				}

			}
			}
		*/
	}//end destroy gems()



	void PrintArray(GameObject[,] gems){//prints the array "gems" with each gameobject position
	string throwAwayString = "";
		for (int y2 = 0; y2<5; y2++) {
		for (int x2 = 0; x2<5; x2++) {
				throwAwayString = throwAwayString + "gem:" + x2 + ": " + y2 + " " + gems[x2,y2].name + " ";
				if (x2 == 5)
				{
					print (throwAwayString);
					throwAwayString = "";
				}
		}
		}

	}//end PrintArray()


	void RemoveGem (GameObject[,] gems, int i, int g)
	{//removes object from array
		gems [i,g] = null;
	}

	void ConsolidateRow(GameObject[] gemRow)
	{
		for (int t=0; t<5; t++) {//loop 1 - 5
		for (int h=5; h>0; h--) {//loop 1 - 5
			//print(gemRow[h]);
			if (gemRow[h] != null) // if there is a gem
			{
				if(gemRow[h-1] == null)// and the next gem is empty
				{
					//print("moved " + h + " to " + (h+1));
					gemRow[h-1] = gemRow[h]; //copy this gem to the next spot
					gemRow[h] = null; //clear the gem spot
				}
			}
		  }
		}
	}//end ConsolidateRow

	bool CheckForMatches(GameObject[,] gems, bool[,] match)
	{
		//check each horizontal row for matches
		for (int hor_Y = 0; hor_Y < 6; hor_Y++)
		{
			for (int hor_X = 0; hor_X<6; hor_X++){
				if(hor_X > 0&& hor_X < 5){
				if(gems[hor_X,hor_Y].name != null && gems[hor_X-1,hor_Y].name != null && gems[hor_X+1,hor_Y].name != null){
				if(gems[hor_X,hor_Y].GetComponent<Gem>().gem == gems[hor_X-1,hor_Y].GetComponent<Gem>().gem &&gems[hor_X,hor_Y].GetComponent<Gem>().gem == gems[hor_X+1,hor_Y].GetComponent<Gem>().gem){
				
				if(match[hor_X,hor_Y]== true && match[hor_X-1,hor_Y]== true||match[hor_X+1,hor_Y]== true && match[hor_X,hor_Y]== true ){
				//4 in a row
				//print ("4 in a row");					
					//match[hor_X,hor_Y]= false;
					//match[hor_X-1,hor_Y]= false;
					//break;
							}else if(match[hor_X+1,hor_Y]== true && match[hor_X,hor_Y]== true ){}
				if ( match[hor_X-1,hor_Y]== true||match[hor_X+1,hor_Y]== true){
				//print ("5 in a row");
								//break;
				//5 in a row
							}else{
				
				//if(gems[hor_X,hor_Y].name == gems[hor_X-1,hor_Y].name && gems[hor_X,hor_Y].name == gems[hor_X+1,hor_Y].name){
					match[hor_X,hor_Y] = true;
					match[hor_X-1,hor_Y] = true;
					match[hor_X+1,hor_Y] = true;
					iCanHasMatch = true;
					StartCoroutine(ChangeScore(1, 1f));
					print ("Horizontal match on square: " + hor_X + ", "+ hor_Y);
					return true;
							}
				}
				}
				}
		}
		}
		//check each vertical row for matches
		for (int vert_Y = 1; vert_Y < 5; vert_Y++)
		{
			for (int vert_X = 0; vert_X<6; vert_X++){
					if(gems[vert_X,vert_Y].name != null && gems[vert_X,vert_Y-1].name != null && gems[vert_X,vert_Y+1].name != null){
					if(gems[vert_X,vert_Y].name == gems[vert_X,vert_Y-1].name && gems[vert_X,vert_Y].name == gems[vert_X,vert_Y+1].name){
						match[vert_X,vert_Y] = true;
						match[vert_X,vert_Y+1] = true;
						match[vert_X,vert_Y-1] = true;
						iCanHasMatch = true;
						StartCoroutine(ChangeScore(1, 1f));
						print ("Horizontal match on square: " + vert_X + ", "+ vert_Y);
						return true;
					}
					}
				
			}
		}
			/*
			if (k-2 > 0){
			if (gems[k-2]!=null && gems[k-1] != null && gems[k] != null && gems[k+1] != null){
			if (gems[k-2].name == gems[k].name && gems[k-1].name == gems[k].name && gems[k+1].name == gems[k].name){
						match[k] = true;
						match[k-1] = true;
						match[k+1] = true;
						match[k-2] = true;
						StartCoroutine(ChangeScore(8, 1f));
						iCanHasMatch = true;
						print ("match 4: " + (k-2) + ", " +(k-1)+ ", " +(k)+ ", " + (k+1));
					}
				}
			}

			else if (k+2 < 36){
			 if (gems[k+2]!=null && gems[k-1] != null && gems[k] != null && gems[k+1] != null){
				if (gems[k+2].name == gems[k].name && gems[k-1].name == gems[k].name && gems[k+1].name == gems[k].name){
							match[k] = true;
							match[k-1] = true;
							match[k+1] = true;
							match[k+2] = true;
							StartCoroutine(ChangeScore(8, 1f));
							iCanHasMatch = true;
							print ("match 4: " + (k-1) + ", " +(k)+ ", " +(k+1)+ ", " + (k+2));
					}
				}
			}
			 if (gems[k-1] != null && gems[k+1] != null && gems[k] != null){
			if (gems[k-1].name == gems[k].name && gems[k+1].name == gems[k].name)
				{
					match[k] = true;
					match[k-1] = true;
					match[k+1] = true;
					print ("Horizontal match on square " + k);
					StartCoroutine(ChangeScore(4, 1f));
					iCanHasMatch = true;
				}
			}
			}
		}//end horizontal check

		//check each vertial collumn for matches
		for (int j = 6; j <= 24; j+=6)
		{
			for (int k = j; k<j+6; k++){
			if (gems[k-6] != null && gems[k] != null && gems[k+6] != null){
			if (gems[k-6].name == gems[k].name && gems[k+6].name == gems[k].name)
				{
					match[k] = true;
					match[k-6] = true;
					match[k+6] = true;
					print ("Vertical match on square " + k);
					StartCoroutine(ChangeScore(4, 1f));
					iCanHasMatch = true;
				}
			}
		  }
		}//end vertical check
		*/
		return iCanHasMatch;
	}//end CheckForMatches()
	void Check()//I made a script combining these two functions cause I'm lazy..
	{
		CheckForMatches (gems, match);
		if (CheckForMatches (gems, match) == false) 
		{
			canDoSomething = true;
		}
		DestroyGems(gems, match);
		RespawnGems (gems);
	}
	IEnumerator ChangeScore(int points, float waitTime)
	{
		if (iCanHasMatch){
		yield return new WaitForSeconds(waitTime);
		score += points;
		print ("Added: " + points + " points.");
		iCanHasMatch = false;
		}
		scoreTxt.text = ("Score: " + score);

	}
	void Update () {

		MouseClickOnGem ();

		for (int y_Loop = 0; y_Loop<6; y_Loop++){
		for (int x_Loop = 0; x_Loop<6; x_Loop++)//LERP each gem in the array from old to new position
		{
			if(gems[x_Loop,y_Loop] != null){
				gems[x_Loop,y_Loop].transform.position = Vector3.MoveTowards(gems[x_Loop,y_Loop].transform.position, gemVector3[x_Loop,y_Loop], Time.deltaTime * 3.3f);
			}else
			{
				match[x_Loop,y_Loop] = true; // mark the empty squares as matches so we know where to make more squares
			}
		}
		}
		  
	}//end Update()
	void MouseClickOnGem()
	{
		ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		if(Physics.Raycast(ray, out hit) && Input.GetMouseButtonDown(0))
		{
			for(int y = 0; y < 6; y++){
			for(int x = 0; x < 6; x++)
			{
				if(hit.collider.gameObject == gems[x,y])//if the mouse clicks on the gem
				{
					gemSecondTouch[0] = gemFirstTouch[0];
					gemSecondTouch[1] = gemFirstTouch[1];
					gemFirstTouch[0] = x;
					gemFirstTouch[1] = y;
					gems[x,y].transform.localScale = new Vector3 (0.7f, 0.7f, 1);
						print ("Touch: " + gemFirstTouch[0] + " "+ gemFirstTouch[1] + " "+gems[gemFirstTouch[0],gemFirstTouch[1]].name +", " + gemSecondTouch[0] + " " + gemSecondTouch[1]);
					/*
					if (gemSecondTouch > 0 && gemSecondTouch < gems.Length){
					gems[gemSecondTouch].transform.localScale = new Vector3 (1f, 1f, 1f);
					}*/


					CheckNeighbors(gemSecondTouch, gemFirstTouch, gems);




					//print("First: " +  gemSecondTouch + " Second: " + gemFirstTouch);
				}
			}
			}
		}
	}
	void CheckNeighbors(int[] n2, int[] n,GameObject[,] gems)
	{
		int x_fir = n[0];
		int y_fir = n[1];
		int x_sec = n2[0];
		int y_sec = n2[1];
		if (x_fir == x_sec && y_fir == y_sec + 1 || x_fir == x_sec && y_fir == y_sec - 1) {//if the gem is up or down
						gems [x_fir, y_fir].transform.position = gemVector3 [x_sec, y_sec];//switch the gem positions
						gems [x_sec, y_sec].transform.position = gemVector3 [x_fir, y_fir];
						gems [x_fir, y_fir].transform.localScale = new Vector3 (1f, 1f, 1f);//reset the scale of the gems
						gems [x_sec, y_sec].transform.localScale = new Vector3 (1f, 1f, 1f);
						StartCoroutine (SwitchGems (n2, n, gems, 0.2f));//switch the gems
						gemFirstTouch = new int[2]{-666, -666}; //reset the gem touch values
						gemSecondTouch = new int[2]{-666, -666};
				} else if (y_fir == y_sec && x_fir == x_sec + 1 || y_fir == y_sec && x_fir == x_sec - 1) {//if the gem is up or down
						gems [x_fir, y_fir].transform.position = gemVector3 [x_sec, y_sec];//switch the gem positions
						gems [x_sec, y_sec].transform.position = gemVector3 [x_fir, y_fir];
						gems [x_fir, y_fir].transform.localScale = new Vector3 (1f, 1f, 1f);//reset the scale of the gems
						gems [x_sec, y_sec].transform.localScale = new Vector3 (1f, 1f, 1f);
						StartCoroutine (SwitchGems (n2, n, gems, 0.2f));//switch the gems
						gemFirstTouch = new int[2]{-666, -666}; //reset the gem touch values
						gemSecondTouch = new int[2]{-666, -666};
				} else if (x_fir != -666 && x_sec != -666){
				gems [x_fir, y_fir].transform.localScale = new Vector3 (1f, 1f, 1f);//reset the scale of the gems
				gems [x_sec, y_sec].transform.localScale = new Vector3 (1f, 1f, 1f);
				//gemFirstTouch = new int[2]{-666, -666}; //reset the gem touch values
				//gemSecondTouch = new int[2]{-666, -666};
				}
		
	}//end CheckNeighbors()
	IEnumerator SwitchGems(int[] n2, int[] n, GameObject[,] gems , float waitTime)
	{
				yield return new WaitForSeconds (waitTime);
		int x_fir = n [0];
		int y_fir = n [1];
		int x_sec = n2 [0];
		int y_sec = n2 [1];

		if(canDoSomething){               //if canDoSomething then switch the gems
				gemCopy = gems [x_fir, y_fir];
				gems [x_fir, y_fir] = gems [x_sec, y_sec];
				gems [x_sec, y_sec] = gemCopy;
				canDoSomething = false;
		}

		if(CheckForMatches(gems, match) == false){//if the gems don't match.  switch them back again
			gemCopy = gems[x_fir, y_fir];
			gems [x_fir, y_fir] = gems [x_sec, y_sec];
			gems [x_sec, y_sec] = gemCopy;
			canDoSomething = true;
		}

	}
	void RespawnGems(GameObject[,] gems)
	{
		for (int y = 0; y<6; y++) {
		for (int x = 0; x<6; x++) {
			if(gems[x,y]==null){
				randomNum = RandomNum();
				gems[x,y] = Instantiate(gemAsset[randomNum], new Vector3(gemVector3[x,y].x, gemVector3[x,y].y + 2.5f,gemVector3[x,y].z), Quaternion.identity) as GameObject;
			}
		}
		}
	}//end RespawnGems
}//end class
